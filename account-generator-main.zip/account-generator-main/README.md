# Treasure Account Generator Template

Simple PHP account generator template

## Installation

Download all the files in this repository for the website to function correctly

## How to use

1. Go to the accounts folder
2. Open the text files and add your accounts in there
3. Upload your website to the main directory (usually public_html) of your web server
4. Go to your domain and the website should be working
5. Disable direct access to the accounts folder


## Support
[My Discord Server](https://discord.gg/mnMMKw6rAc)
